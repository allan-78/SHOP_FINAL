<?php
require_once 'includes/functions/functions.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

try {
    if (!isset($pdo)) {
        $pdo = new PDO("mysql:host=localhost;dbname=shoeshop", "root", "");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    // Query to fetch return history for the logged-in user
    $sql = "
        SELECT 
            r.id,
            p.name AS product_name,
            r.quantity,
            r.reason,
            r.status,
            r.created_at
        FROM 
            returns r
        JOIN 
            order_items oi ON r.order_item_id = oi.id
        JOIN 
            products p ON oi.product_id = p.product_id
        WHERE 
            r.user_id = :user_id
        ORDER BY 
            r.created_at DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['user_id' => $user_id]);
    $returns = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return History - EmShoe</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .status-pending {
            color: #ffc107;
        }
        .status-approved {
            color: #28a745;
        }
        .status-rejected {
            color: #dc3545;
        }
    </style>
</head>
<body>
<?php include 'templates/header.php'; ?>
<div class="container">
    <h2 class="mb-4">Return History</h2>
    <?php if (!empty($returns)): ?>
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>#</th>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Reason</th>
                    <th>Status</th>
                    <th>Submitted At</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($returns as $index => $return): ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td><?php echo htmlspecialchars($return['product_name']); ?></td>
                        <td><?php echo htmlspecialchars($return['quantity']); ?></td>
                        <td><?php echo htmlspecialchars($return['reason']); ?></td>
                        <td class="status-<?php echo strtolower($return['status']); ?>">
                            <?php echo ucfirst($return['status']); ?>
                        </td>
                        <td><?php echo htmlspecialchars($return['created_at']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-center">No return requests found.</p>
    <?php endif; ?>
</div>
</body>
</html>
