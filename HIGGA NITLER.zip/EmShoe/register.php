<?php
session_start(); // Start the session for handling messages

// Database connection
$servername = "localhost";
$db_username = "root"; // Update with your database username
$db_password = ""; // Update with your database password
$dbname = "shoeshop"; // Update with your database name

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Encrypt the password
    $confirm_password = $_POST['confirm_password'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $role = $_POST['role']; // 'user' or 'admin'

    // Check if a profile picture is uploaded
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $profile_picture = $_FILES['profile_picture'];
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        $file_extension = pathinfo($profile_picture['name'], PATHINFO_EXTENSION);

        // Validate file type
        if (in_array(strtolower($file_extension), $allowed_extensions)) {
            $profile_picture_path = 'uploads/' . uniqid() . '.' . $file_extension;
            move_uploaded_file($profile_picture['tmp_name'], $profile_picture_path);
        } else {
            $_SESSION['message'] = "Invalid file type for profile picture. Only JPG, JPEG, PNG, and GIF are allowed.";
            header('Location: register.php');
            exit();
        }
    } else {
        $profile_picture_path = null; // If no picture is uploaded
    }

    // Validate password confirmation
    if ($_POST['password'] !== $confirm_password) {
        $_SESSION['message'] = "Passwords do not match!";
    } else {
        // Check if the username already exists in the database
        $check_sql = "SELECT * FROM Users WHERE username = ?";
        $stmt = $conn->prepare($check_sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $_SESSION['message'] = "Username is already taken. Please choose another one.";
        } else {
            // Insert into the appropriate table based on the role
            if ($role === 'user') {
                $sql = "INSERT INTO Users (username, password, email, first_name, last_name, phone, address, role, profile_picture) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sssssssss", $username, $password, $email, $first_name, $last_name, $phone, $address, $role, $profile_picture_path);
            } elseif ($role === 'admin') {
                $sql = "INSERT INTO admin_users (username, password) 
                        VALUES (?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $username, $password);
            }

            // Execute the statement and set session messages
            if ($stmt->execute()) {
                if ($role === 'user') {
                    $_SESSION['message'] = "User account successfully created. <a href='login.php'>Click here to login</a>.";
                } elseif ($role === 'admin') {
                    $_SESSION['message'] = "Admin account successfully created. <a href='admin/index.php'>Click here to login</a>.";
                }
            } else {
                $_SESSION['message'] = "Error: " . $stmt->error;
            }
        }

        $stmt->close();
    }

    // Redirect to the registration page
    header('Location: register.php');
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | EM' Quality Shoes</title>
    <!-- Include Bootstrap CSS here -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f9f9f9;
            padding-top: 50px;
            color: #333;
        }

        /* Header and Footer */
        header, footer {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        header a, footer a {
            color: #fff;
            text-decoration: none;
            font-size: 24px;
            font-weight: bold;
        }

        header a:hover {
            text-decoration: none;
            color: #FFD700;
            text-shadow: 0 0 10px rgba(255, 215, 0, 0.7), 0 0 20px rgba(255, 215, 0, 0.5);
        }

        /* Register Form Section */
        .register-section {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-size: 16px;
        }

        .form-input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            margin-top: 5px;
        }

        textarea.form-input {
            height: 100px;
        }

        input[type="radio"] {
            margin-right: 5px;
        }

        .role-options {
            display: flex;
            justify-content: center;
            margin-top: 10px;
        }

        .submit-btn {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        .submit-btn:focus, .form-input:focus {
            outline: none;
            border-color: #007bff;
        }

        @media (max-width: 600px) {
            .register-section {
                width: 90%;
            }
        }
    </style>
</head>
<body>

    <header>
        <a href="index.php">EM' Quality Shoes</a>
    </header>

    <main>
        <section class="register-section">
            <h2>Register</h2>
            
            <!-- Display error message if exists -->
            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert-error">
                    <?php echo $_SESSION['message']; ?>
                </div>
                <?php unset($_SESSION['message']); ?>
            <?php endif; ?>

            <form method="POST" action="register.php" enctype="multipart/form-data" class="register-form">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required class="form-input">
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required class="form-input">
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required class="form-input">
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" required class="form-input">
                </div>
                
                <div class="form-group">
                    <label for="first_name">First Name</label>
                    <input type="text" id="first_name" name="first_name" required class="form-input">
                </div>
                
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <input type="text" id="last_name" name="last_name" required class="form-input">
                </div>

                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" id="phone" name="phone" class="form-input">
                </div>

                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea id="address" name="address" class="form-input"></textarea>
                </div>

                <div class="role-options">
                    <label>
                        <input type="radio" name="role" value="user" required> User
                    </label>
                    <label>
                        <input type="radio" name="role" value="admin"> Admin
                    </label>
                </div>

                <div class="form-group">
                    <label for="profile_picture">Profile Picture</label>
                    <input type="file" id="profile_picture" name="profile_picture" class="form-input">
                </div>

                <div class="form-group">
                    <button type="submit" class="submit-btn">Register</button>
                </div>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 EM' Quality Shoes. All rights reserved.</p>
    </footer>

</body>
</html>
