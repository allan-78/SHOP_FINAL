<?php
require_once '../includes/functions/functions.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: index.php");
    exit;
}

// Database connection and required functions
$servername = "localhost"; // Your DB server name
$username = "root"; // Your DB username
$password = ""; // Your DB password
$dbname = "shoeshop"; // Your DB name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch review by ID function (for editing)
function getReviewById($conn, $review_id) {
    $sql = "SELECT reviews.*, products.product_name FROM reviews 
            JOIN products ON reviews.product_id = products.id 
            WHERE reviews.id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $review_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

// Update review function
function updateReview($conn, $review_id, $review_text, $rating) {
    $sql = "UPDATE reviews SET review_text = ?, rating = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sii", $review_text, $rating, $review_id);
    return $stmt->execute();
}

// Add notification function
function addNotification($conn, $user_id, $message) {
    $sql = "INSERT INTO notifications (user_id, message) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $user_id, $message);
    return $stmt->execute();
}

// Handle review edit form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_review'])) {
    $review_id = $_POST['review_id'];
    $review_text = $_POST['review_text'];
    $rating = $_POST['rating'];

    // Update the review in the database
    if (updateReview($conn, $review_id, $review_text, $rating)) {
        // Get the review details for the notification
        $review = getReviewById($conn, $review_id);
        
        // Send notification to the user
        $notification_message = "Your review for product '{$review['product_name']}' has been updated by the admin.";
        addNotification($conn, $review['user_id'], $notification_message);
        
        $_SESSION['message'] = "Review updated successfully!";
        header("Location: comments.php");
        exit;
    } else {
        $_SESSION['message'] = "Failed to update review.";
    }
}

// Fetch the review data to prefill the form
if (isset($_GET['id'])) {
    $review_id = $_GET['id'];
    $review = getReviewById($conn, $review_id);
    if (!$review) {
        $_SESSION['message'] = "Review not found.";
        header("Location: comments.php");
        exit;
    }
} else {
    $_SESSION['message'] = "Invalid request.";
    header("Location: comments.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Review - Admin</title>
    <link rel="stylesheet" href="../layout/css/admin.css">
</head>
<body>
    <div class="container">
        <h1>Edit Review for Product: <?php echo htmlspecialchars($review['product_name']); ?></h1>

        <!-- Display messages if any -->
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert">
                <?php echo $_SESSION['message']; ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="review_id" value="<?php echo $review['id']; ?>">

            <div class="form-group">
                <label for="rating">Rating:</label>
                <input type="number" name="rating" id="rating" value="<?php echo $review['rating']; ?>" min="1" max="5" required>
            </div>

            <div class="form-group">
                <label for="review_text">Review:</label>
                <textarea name="review_text" id="review_text" rows="4" required><?php echo htmlspecialchars($review['review_text']); ?></textarea>
            </div>

            <div class="form-group">
                <button type="submit" name="update_review">Update Review</button>
            </div>
        </form>

        <a href="comments.php">Back to Reviews</a>
    </div>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
