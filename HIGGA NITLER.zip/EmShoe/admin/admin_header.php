<!-- templates/admin_header.php -->
<header>
    <div class="search">
        <input type="text" placeholder="Search...">
    </div>
</header>

<div class="sidebar">
    <div class="logo">Admin Dashboard</div>
    <a href="dashboard.php">Dashboard</a>
    <a href="members.php">Manage Users</a>
    <a href="items.php">Manage Products</a>
    <a href="categories.php">Manage Categories</a>
    <a href="return_management.php">Manage Refund</a>
    <a href="add_item.php">Add Product</a>
    <a href="add_category.php">Add Category</a>
    <a href="add_user.php">Add User</a>
    <a href="comments.php">Product Reviews</a>
    <a href="recent_orders.php">Recent Orders</a>
    <a href="logout.php">Logout</a>

</div>
