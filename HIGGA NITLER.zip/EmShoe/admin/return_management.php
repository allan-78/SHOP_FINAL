<?php
session_start();

function dbConnect() {
    try {
        // Database credentials
        $host = 'localhost';
        $dbname = 'shoeshop';
        $username = 'root';
        $password = ''; // Change this if you use a password for MySQL

        // Create a PDO instance
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);

        // Set error mode to exception for debugging
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        return $pdo;
    } catch (PDOException $e) {
        // Handle connection error
        die('Database connection failed: ' . $e->getMessage());
    }
}

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: index.php");
    exit;
}

// Handle form submission to update return status
if (isset($_POST['update_status']) && isset($_POST['return_id']) && isset($_POST['status'])) {
    $return_id = filter_input(INPUT_POST, 'return_id', FILTER_SANITIZE_NUMBER_INT);
    $new_status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);

    // Connect to the database
    $pdo = dbConnect();

    try {
        // Start a transaction
        $pdo->beginTransaction();

        // Step 1: Update the return status to the new status
        $stmt = $pdo->prepare("UPDATE returns SET status = :status WHERE id = :return_id");
        $stmt->execute([':status' => $new_status, ':return_id' => $return_id]);

        // Step 2: If the status is "approved", update the order's status to "returned"
        if ($new_status === 'approved') {
            // Fetch the order_id associated with the return request
            $stmt = $pdo->prepare("SELECT o.id FROM orders o
                                   JOIN order_items oi ON o.id = oi.order_id
                                   JOIN returns r ON oi.id = r.order_item_id
                                   WHERE r.id = :return_id");
            $stmt->execute([':return_id' => $return_id]);
            $order = $stmt->fetch(PDO::FETCH_ASSOC);

            // If the order is found, update its status to 'returned'
            if ($order) {
                $stmt = $pdo->prepare("UPDATE orders SET status = 'returned' WHERE id = :order_id");
                $stmt->execute([':order_id' => $order['id']]);
            }
        }

        // Step 3: Commit the transaction
        $pdo->commit();

        // Step 4: Send a notification to the user about the refund
        $stmt = $pdo->prepare("SELECT u.id, p.name FROM returns r
                               JOIN users u ON r.user_id = u.id
                               JOIN products p ON r.product_id = p.product_id
                               WHERE r.id = :return_id");
        $stmt->execute([':return_id' => $return_id]);
        $return = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($return) {
            $stmt = $pdo->prepare("INSERT INTO notifications (user_id, message, created_at) 
                                   VALUES (:user_id, :message, NOW())");
            $stmt->execute([
                ':user_id' => $return['id'],
                ':message' => "Your return request for product {$return['name']} has been approved and your order is now marked as returned."
            ]);
        }

        // Redirect with success message
        $_SESSION['message'] = "Return request status updated successfully!";
        header("Location: return_management.php");
        exit;

    } catch (Exception $e) {
        // Rollback the transaction if an error occurs
        $pdo->rollBack();
        $_SESSION['message'] = "Error: " . $e->getMessage();
        header("Location: return_management.php");
        exit;
    } finally {
        // Close the database connection
        $pdo = null;
    }
}

// Fetch return requests
$pdo = dbConnect();
$stmt = $pdo->query("SELECT r.id, r.reason, r.status, r.created_at, u.username, p.name AS product_name
                     FROM returns r
                     JOIN users u ON r.user_id = u.id
                     JOIN products p ON r.product_id = p.product_id");
$returns = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return Management</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Return Requests</h2>

    <?php
    // Display session message if any
    if (isset($_SESSION['message'])) {
        echo '<div class="alert alert-success">' . htmlspecialchars($_SESSION['message']) . '</div>';
        unset($_SESSION['message']); // Clear message after displaying
    }
    ?>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Return ID</th>
                <th>Product</th>
                <th>User</th>
                <th>Reason</th>
                <th>Status</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($returns)): ?>
                <?php foreach ($returns as $return): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($return['id']); ?></td>
                        <td><?php echo htmlspecialchars($return['product_name']); ?></td>
                        <td><?php echo htmlspecialchars($return['username']); ?></td>
                        <td><?php echo htmlspecialchars($return['reason']); ?></td>
                        <td><?php echo htmlspecialchars($return['status']); ?></td>
                        <td><?php echo htmlspecialchars($return['created_at']); ?></td>
                        <td>
                            <form method="POST" action="return_management.php">
                                <input type="hidden" name="return_id" value="<?php echo htmlspecialchars($return['id']); ?>">
                                <select name="status" class="form-control mb-2">
                                    <option value="pending" <?php if ($return['status'] == 'pending') echo 'selected'; ?>>Pending</option>
                                    <option value="approved" <?php if ($return['status'] == 'approved') echo 'selected'; ?>>Approved</option>
                                    <option value="rejected" <?php if ($return['status'] == 'rejected') echo 'selected'; ?>>Rejected</option>
                                </select>
                                <button type="submit" name="update_status" class="btn btn-primary btn-sm">Update</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center">No return requests found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
