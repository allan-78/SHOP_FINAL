<?php
// Direct database connection
$servername = "localhost";  // Change this to your server name
$username = "root";         // Your MySQL username
$password = "";             // Your MySQL password
$dbname = "shoeshop";       // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch total users
$totalUsersQuery = "SELECT COUNT(*) AS total_users FROM users";
$totalUsersResult = $conn->query($totalUsersQuery);
$totalUsers = $totalUsersResult->fetch_assoc()['total_users'];

// Fetch total products
$totalProductsQuery = "SELECT COUNT(*) AS total_products FROM products";
$totalProductsResult = $conn->query($totalProductsQuery);
$totalProducts = $totalProductsResult->fetch_assoc()['total_products'];

// Fetch total orders
$totalOrdersQuery = "SELECT COUNT(*) AS total_orders FROM orders";
$totalOrdersResult = $conn->query($totalOrdersQuery);
$totalOrders = $totalOrdersResult->fetch_assoc()['total_orders'];

// Fetch total sales amount
$totalSalesQuery = "
    SELECT SUM(oi.price * oi.quantity) AS total_sales
    FROM order_items oi
    JOIN orders o ON oi.order_id = o.id
    WHERE o.status = 'completed'
";
$totalSalesResult = $conn->query($totalSalesQuery);
$totalSales = $totalSalesResult->fetch_assoc()['total_sales'];

// Check if totalSales is null (in case no completed orders) and set it to 0
if ($totalSales === null) {
    $totalSales = 0;
}

// Fetch best-selling product (highest quantity sold)
$bestSellingProductQuery = "
    SELECT p.name, SUM(oi.quantity) AS total_quantity
    FROM order_items oi
    JOIN products p ON oi.product_id = p.product_id
    JOIN orders o ON oi.order_id = o.id
    WHERE o.status = 'completed'
    GROUP BY p.product_id
    ORDER BY total_quantity DESC
    LIMIT 1
";
$bestSellingProductResult = $conn->query($bestSellingProductQuery);
$bestSellingProduct = $bestSellingProductResult->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        /* Sidebar Styling */
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            padding-top: 20px;
            color: #fff;
        }

        .sidebar a {
            padding: 10px 20px;
            text-decoration: none;
            font-size: 1.1em;
            display: block;
            color: #fff;
            margin-bottom: 10px;
            border-radius: 5px;
        }

        .sidebar a:hover {
            background-color: #555;
        }

        .sidebar .logo {
            font-size: 1.5em;
            font-weight: bold;
            text-align: center;
            margin-bottom: 30px;
        }

        /* Main Content Styling */
        main {
            margin-left: 260px;  /* Offset by the sidebar width */
            padding: 20px;
        }

        header {
            background-color: #343a40;
            color: #fff;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .search input {
            padding: 8px;
            border-radius: 20px;
            border: 1px solid #ccc;
        }

        .dashboard {
            padding: 20px;
        }

        .stats {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .stat {
            text-align: center;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
            flex: 1;
            margin: 0 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .stat h2 {
            margin: 0 0 10px;
            font-size: 1.2em;
            color: #555;
        }

        .stat p {
            margin: 0;
            font-size: 1.5em;
            font-weight: bold;
            color: #333;
        }

        .charts {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .chart {
            width: 48%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .chart h2 {
            font-size: 1.2em;
            margin-bottom: 10px;
        }

        .latest-orders {
            margin-top: 20px;
        }

        .latest-orders h2 {
            font-size: 1.5em;
            margin-bottom: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
            font-weight: bold;
        }

        td {
            font-size: 0.9em;
            color: #333;
        }
    </style>
</head>
<?php include('admin_header.php'); ?>

<body>

    <!-- Main Content -->
    <main>
        <header>
            <div class="search">
                <input type="text" placeholder="Search...">
            </div>
        </header>

        <section class="dashboard">
            <h1>Dashboard</h1>

            <!-- Stats Section -->
            <div class="stats">
                <div class="stat">
                    <h2>Total Users</h2>
                    <p><?php echo $totalUsers; ?></p>
                </div>
                <div class="stat">
                    <h2>Total Products</h2>
                    <p><?php echo $totalProducts; ?></p>
                </div>
                <div class="stat">
                    <h2>Total Orders</h2>
                    <p><?php echo $totalOrders; ?></p>
                </div>
                <div class="stat">
                    <h2>Total Sales</h2>
                    <p>$<?php echo number_format($totalSales, 2); ?></p>
                </div>
            </div>

            <!-- Best-Selling Product Section -->
            <div class="charts">
                <div class="chart">
                    <h2>Best-Selling Product</h2>
                    <?php if ($bestSellingProduct): ?>
                        <p><?php echo $bestSellingProduct['name']; ?></p>
                        <p>Total Sold: <?php echo $bestSellingProduct['total_quantity']; ?></p>
                    <?php else: ?>
                        <p>No best-selling product data available.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Latest Orders Section -->
            <div class="latest-orders">
                <h2>Latest Orders</h2>
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    // Fetching latest orders from the database
                   // Fetching latest orders from the database
$latestOrdersQuery = "
SELECT oi.order_id, CONCAT(u.first_name, ' ', u.last_name) AS full_name, u.email, 
       SUM(oi.price * oi.quantity) AS amount, o.status, o.created_at AS order_date
FROM order_items oi
JOIN orders o ON oi.order_id = o.id
JOIN users u ON o.user_id = u.id
GROUP BY oi.order_id
ORDER BY o.created_at DESC
LIMIT 5
";
$latestOrdersResult = $conn->query($latestOrdersQuery);


                    if ($latestOrdersResult->num_rows > 0) {
                        $count = 1;
                        while ($order = $latestOrdersResult->fetch_assoc()) {
                            echo "<tr>
                                    <td>{$count}</td>
                                    <td>{$order['full_name']}</td>
                                    <td>{$order['email']}</td>
                                    <td>$" . number_format($order['amount'], 2) . "</td>
                                    <td>{$order['status']}</td>
                                    <td>{$order['order_date']}</td>
                                  </tr>";
                            $count++;
                        }
                    } else {
                        echo "<tr><td colspan='6'>No recent orders</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>
            </div>

        </section>
    </main>

</body>
</html>

<?php $conn->close(); ?>
                    