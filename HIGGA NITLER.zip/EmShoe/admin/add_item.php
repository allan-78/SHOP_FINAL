<?php
require_once '../includes/functions/functions.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: index.php");
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect and sanitize form data
    $name = htmlspecialchars(trim($_POST['name']));
    $description = htmlspecialchars(trim($_POST['description']));
    $category_id = intval($_POST['category_id']);
    $price = floatval($_POST['price']);
    $gender = htmlspecialchars(trim($_POST['gender']));
    $age_group = htmlspecialchars(trim($_POST['age_group']));
    $size = htmlspecialchars(trim($_POST['size']));
    $color = htmlspecialchars(trim($_POST['color']));
    $rating = floatval($_POST['rating']);

    // Handle image upload
    $image = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $imageTmpPath = $_FILES['image']['tmp_name'];
        $imageName = $_FILES['image']['name'];
        $imageSize = $_FILES['image']['size'];
        $imageType = $_FILES['image']['type'];

        // Validate image type and size (optional)
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (in_array($imageType, $allowedTypes) && $imageSize <= 5 * 1024 * 1024) { // 5MB max
            $imagePath = '../uploads/products/' . $imageName;
            move_uploaded_file($imageTmpPath, $imagePath);
            $image = $imageName;
        } else {
            $error = 'Invalid image file. Only JPEG, PNG, GIF allowed and max size 5MB.';
        }
    }

    // Insert product into the database
    if (!isset($error)) {
        $query = "INSERT INTO products (name, description, category_id, price, image, gender, age_group, size, color, rating) 
                  VALUES ('$name', '$description', '$category_id', '$price', '$image', '$gender', '$age_group', '$size', '$color', '$rating')";

        if ($conn->query($query) === TRUE) {
            $success = 'Product added successfully!';
        } else {
            $error = 'Error adding product: ' . $conn->error;
        }
    }
}

// Get categories for the select dropdown
$categories = getCategories();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Add New Shoe</title>
    <!-- Bootstrap 4 CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS (optional) -->
    <link rel="stylesheet" href="../layout/css/admin.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Add New Shoe</h1>

        <!-- Display success or error messages -->
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php elseif (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Product Form -->
        <form method="post" enctype="multipart/form-data">
            <div class="form-row">
                <!-- Name Input -->
                <div class="form-group col-md-6">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" class="form-control" required>
                </div>

                <!-- Price Input -->
                <div class="form-group col-md-6">
                    <label for="price">Price:</label>
                    <input type="number" id="price" name="price" class="form-control" required step="0.01">
                </div>
            </div>

            <div class="form-row">
                <!-- Description Input -->
                <div class="form-group col-md-12">
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" class="form-control" rows="4"></textarea>
                </div>
            </div>

            <div class="form-row">
                <!-- Category Select -->
                <div class="form-group col-md-6">
                    <label for="category">Category:</label>
                    <select id="category" name="category_id" class="form-control" required>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo $category['id']; ?>"><?php echo $category['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <!-- Gender Select (Radio Buttons) -->
                <div class="form-group col-md-6">
                    <label>Gender:</label><br>
                    <label for="gender_male">
                        <input type="radio" id="gender_male" name="gender" value="Male" required> Male
                    </label>
                    <label for="gender_female" class="ml-3">
                        <input type="radio" id="gender_female" name="gender" value="Female" required> Female
                    </label>
                </div>

                <!-- Age Group Select -->
                <div class="form-group col-md-6">
                    <label for="age_group">Age Group:</label>
                    <select id="age_group" name="age_group" class="form-control" required>
                        <option value="Kids">Kids</option>
                        <option value="Teens">Teens</option>
                        <option value="Adults">Adults</option>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <!-- Size Select -->
                <div class="form-group col-md-6">
                    <label for="size">Size:</label>
                    <select id="size" name="size" class="form-control" required>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                    </select>
                </div>

                <!-- Color Select -->
                <div class="form-group col-md-6">
                    <label for="color">Color:</label>
                    <select id="color" name="color" class="form-control" required>
                        <option value="Black">Black</option>
                        <option value="White">White</option>
                        <option value="Red">Red</option>
                        <option value="Blue">Blue</option>
                        <option value="Green">Green</option>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <!-- Rating Select -->
                <div class="form-group col-md-6">
                    <label for="rating">Rating:</label>
                    <select id="rating" name="rating" class="form-control" required>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>

                <!-- Image Upload -->
                <div class="form-group col-md-6">
                    <label for="image">Image:</label>
                    <input type="file" id="image" name="image" class="form-control-file" accept="image/*">
                </div>
            </div>

            <!-- Submit Button -->
            <div class="form-row">
                <div class="col-md-12 text-center">
                    <button type="submit" class="btn btn-primary">Add Product</button>
                </div>
            </div>
        </form>

        <!-- Back to Inventory and Logout Links -->
        <div class="mt-4 text-center">
            <a href="items.php" class="btn btn-secondary">Back to Inventory</a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </div>

    <!-- Bootstrap 4 JS, Popper.js, and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>  
</html>
