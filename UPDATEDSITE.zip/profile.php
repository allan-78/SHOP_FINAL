<?php
include('includes/functions/functions.php'); // Assuming your PDO connection and functions are here

// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details from the database
$stmt = $pdo->prepare("SELECT * FROM Users WHERE id = :user_id");
$stmt->execute(['user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Default profile picture if none is set
$profile_picture = $user['profile_picture'] ? $user['profile_picture'] : 'uploads/profile_pics/default.jpg';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .profile-img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            display: block;
            margin: 0 auto 20px auto;
        }

        .profile-buttons {
            text-align: center;
            margin-top: 30px;
        }

        .profile-buttons a {
            display: inline-block;
            margin: 10px 15px;
            padding: 10px 20px;
            background-color: #3f51b5;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .profile-buttons a:hover {
            background-color: #5c6bc0;
        }

        footer {
            background-color: #3f51b5;
            color: white;
            text-align: center;
            padding: 15px 0;
            margin-top: 40px;
        }
    </style>
</head>
<body>
    <?php include 'templates/header.php'; ?>

    <div class="container mt-5">
        <h2>Your Profile</h2>
        <div class="text-center">
            <img src="<?php echo $profile_picture; ?>" alt="Profile Picture" class="profile-img">
        </div>
        <div class="form-group">
            <label for="first_name" class="form-label">First Name:</label>
            <p><?php echo htmlspecialchars($user['first_name']); ?></p>
        </div>
        <div class="form-group">
            <label for="last_name" class="form-label">Last Name:</label>
            <p><?php echo htmlspecialchars($user['last_name']); ?></p>
        </div>
        <div class="form-group">
            <label for="email" class="form-label">Email:</label>
            <p><?php echo htmlspecialchars($user['email']); ?></p>
        </div>

        <!-- Profile buttons -->
        <div class="profile-buttons">
            <a href="my_reviews.php">My Reviews</a>
            <a href="edit_profile.php">Edit Profile</a>
            <a href="ordered_items.php">Ordered Items</a>
            <a href="order_history.php">Order History</a>
            <a href="settings.php">Settings</a>
            <a href="return.php">Refund</a>
            <a href="return_history.php">Refund History</a>

        </div>

    </div>

    <footer>
        <p>&copy; 2024 EM' Quality Shoes. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
