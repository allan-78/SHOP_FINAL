<?php
require_once '../includes/functions/functions.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: index.php");
    exit;
}

// Database connection and required functions
$servername = "localhost"; // Your DB server name
$username = "root"; // Your DB username
$password = ""; // Your DB password
$dbname = "shoeshop"; // Your DB name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch reviews function
function getReviews($conn) {
    $reviews = [];
    $sql = "SELECT r.id, r.product_id, r.user_id, r.review_text, r.rating, r.created_at, p.name AS product_name, u.username AS user_name
            FROM reviews r
            JOIN products p ON r.product_id = p.product_id
            JOIN users u ON r.user_id = u.id
            ORDER BY r.created_at DESC";
    
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $reviews[] = $row;
        }
    }
    return $reviews;
}

// Fetch review by ID function (for editing)
function getReviewById($conn, $review_id) {
    $sql = "SELECT * FROM reviews WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $review_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

// Update review function
function updateReview($conn, $review_id, $review_text, $rating) {
    $sql = "UPDATE reviews SET review_text = ?, rating = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sii", $review_text, $rating, $review_id);
    return $stmt->execute();
}

// Delete review function
function deleteReview($conn, $review_id) {
    $sql = "DELETE FROM reviews WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $review_id);
    return $stmt->execute();
}

// Add notification function
function addNotification($conn, $user_id, $message) {
    $sql = "INSERT INTO notifications (user_id, message) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $user_id, $message);
    return $stmt->execute();
}

// Handle review modification (Edit or Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_review'])) {
        $review_id = $_POST['review_id'];
        $review_text = $_POST['review_text'];
        $rating = $_POST['rating'];
        
        // Update review
        if (updateReview($conn, $review_id, $review_text, $rating)) {
            // Get the review details
            $review = getReviewById($conn, $review_id);
            
            // Notify the user about review modification
            $notification_message = "Your review for product '{$review['product_name']}' has been updated by the admin.";
            addNotification($conn, $review['user_id'], $notification_message);
            
            $_SESSION['message'] = "Review updated successfully!";
            header("Location: comments.php");
            exit;
        } else {
            $_SESSION['message'] = "Failed to update review.";
        }
    }
    if (isset($_POST['delete_review'])) {
        $review_id = $_POST['review_id'];
        
        // Get the review details before deleting
        $review = getReviewById($conn, $review_id);
        
        // Delete review
        if (deleteReview($conn, $review_id)) {
            // Notify the user about the deletion
            $notification_message = "Your review for product '{$review['product_name']}' has been deleted by the admin.";
            addNotification($conn, $review['user_id'], $notification_message);
            
            $_SESSION['message'] = "Review deleted successfully!";
            header("Location: comments.php");
            exit;
        } else {
            $_SESSION['message'] = "Failed to delete review.";
        }
    }
}

// Fetch all reviews for display
$reviews = getReviews($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Product Reviews</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        h1 {
            color: #333;
        }
        .alert {
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            margin-top: 30px;
        }
        table th, table td {
            text-align: center;
        }
        table th {
            background-color: #007bff;
            color: white;
        }
        table td {
            background-color: #ffffff;
        }
        .btn-edit, .btn-delete {
            margin: 0 5px;
        }
        .btn-custom {
            background-color: #28a745;
            color: white;
            font-weight: bold;
        }
        .btn-custom:hover {
            background-color: #218838;
        }
        .btn-primary:hover, .btn-danger:hover {
            background-color: #0056b3;
            border-color: #004085;
        }
        .back-links {
            margin-top: 30px;
            display: flex;
            gap: 20px;
        }
        .btn-dashboard {
    background-color: #007bff;
    color: white;
    font-weight: bold;
    text-decoration: none;
    padding: 10px 20px;
    border-radius: 5px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.btn-dashboard:hover {
    background-color: #0056b3;
    transform: translateY(-5px); /* Moves the button up */
    box-shadow: 0 8px 12px rgba(0, 0, 0, 0.2); /* Creates a larger shadow */
}

    </style>
</head>
<body>
    <div class="container">
        <h1>Product Reviews</h1>

        <!-- Display messages if any -->
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-info">
                <?php echo $_SESSION['message']; ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
        
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Product</th>
                    <th>User</th>
                    <th>Rating</th>
                    <th>Review</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($reviews as $review): ?>
                    <tr>
                        <td><?php echo $review['id']; ?></td>
                        <td><?php echo htmlspecialchars($review['product_name']); ?></td>
                        <td><?php echo htmlspecialchars($review['user_name']); ?></td>
                        <td><?php echo $review['rating']; ?> / 5</td>
                        <td><?php echo htmlspecialchars($review['review_text']); ?></td>
                        <td>
                            <a href="edit_review.php?id=<?php echo $review['id']; ?>" class="btn btn-primary btn-sm btn-edit">Edit</a>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="review_id" value="<?php echo $review['id']; ?>">
                                <button type="submit" name="delete_review" class="btn btn-danger btn-sm btn-delete" onclick="return confirm('Are you sure you want to delete this review?');">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="back-links">
            <a href="dashboard.php" class="btn-dashboard">Back to Dashboard</a>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
