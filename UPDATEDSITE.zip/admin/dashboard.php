<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shoeshop";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch total users
$totalUsersQuery = "SELECT COUNT(*) AS total_users FROM users";
$totalUsersResult = $conn->query($totalUsersQuery);
$totalUsers = $totalUsersResult->fetch_assoc()['total_users'];

// Fetch total products
$totalProductsQuery = "SELECT COUNT(*) AS total_products FROM products";
$totalProductsResult = $conn->query($totalProductsQuery);
$totalProducts = $totalProductsResult->fetch_assoc()['total_products'];

// Fetch total orders
$totalOrdersQuery = "SELECT COUNT(*) AS total_orders FROM orders";
$totalOrdersResult = $conn->query($totalOrdersQuery);
$totalOrders = $totalOrdersResult->fetch_assoc()['total_orders'];

// Fetch total sales amount
$totalSalesQuery = "
    SELECT SUM(oi.price * oi.quantity) AS total_sales
    FROM order_items oi
    JOIN orders o ON oi.order_id = o.id
    WHERE o.status = 'completed'
";
$totalSalesResult = $conn->query($totalSalesQuery);
$totalSales = $totalSalesResult->fetch_assoc()['total_sales'];

// Handle null sales value
$totalSales = $totalSales ? $totalSales : 0;

// Fetch best-selling product
$bestSellingProductQuery = "
    SELECT p.name, SUM(oi.quantity) AS total_quantity
    FROM order_items oi
    JOIN products p ON oi.product_id = p.product_id
    JOIN orders o ON oi.order_id = o.id
    WHERE o.status = 'completed'
    GROUP BY p.product_id
    ORDER BY total_quantity DESC
    LIMIT 1
";
$bestSellingProductResult = $conn->query($bestSellingProductQuery);
$bestSellingProduct = $bestSellingProductResult->fetch_assoc();

// Fetch latest orders
$latestOrdersQuery = "
    SELECT oi.order_id, CONCAT(u.first_name, ' ', u.last_name) AS full_name, u.email, 
           SUM(oi.price * oi.quantity) AS amount, o.status, o.created_at AS order_date
    FROM order_items oi
    JOIN orders o ON oi.order_id = o.id
    JOIN users u ON o.user_id = u.id
    GROUP BY oi.order_id
    ORDER BY o.created_at DESC
    LIMIT 5
";
$latestOrdersResult = $conn->query($latestOrdersQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        main {
            margin-left: 260px;
            padding: 20px;
        }

        .dashboard {
            padding: 20px;
        }

        .stats {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

    /* Hover effect for stats */
.stat {
    text-align: center;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #fff;
    flex: 1;
    margin: 0 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease, background-color 0.3s ease;
}

.stat:hover {
    transform: translateY(-5px) scale(1.03); /* Float effect with slight scaling */
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); /* Enhanced shadow */
    background-color: #f0f8ff; /* Light blue background on hover */
}

.stat h2, .stat p {
    transition: color 0.3s ease;
}

.stat:hover h2, .stat:hover p {
    color: #0056b3; /* Change text color on hover */
}


        .stat h2 {
            margin: 0 0 10px;
            font-size: 1.2em;
            color: #555;
        }

        .stat p {
            margin: 0;
            font-size: 1.5em;
            font-weight: bold;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
            font-weight: bold;
        }

        td {
            font-size: 0.9em;
            color: #333;
        }

        tbody tr {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

tbody tr:hover {
    transform: translateY(-3px); /* Slightly lifts the row */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15); /* Adds a shadow */
    background-color: #f9f9f9; /* Changes the background color */
}

tbody tr:hover td {
    color: #0056b3; /* Changes the text color */
}

    </style>
</head>
<body>

<?php include('admin_header.php'); ?>

<main>
    <section class="dashboard">
        <h1>Dashboard</h1>
        <div class="stats">
            <div class="stat">
                <h2>Total Users</h2>
                <p><?php echo $totalUsers; ?></p>
            </div>
            <div class="stat">
                <h2>Total Products</h2>
                <p><?php echo $totalProducts; ?></p>
            </div>
            <div class="stat">
                <h2>Total Orders</h2>
                <p><?php echo $totalOrders; ?></p>
            </div>
            <div class="stat">
                <h2>Total Sales</h2>
                <p>$<?php echo number_format($totalSales, 2); ?></p>
            </div>
        </div>

        <h2>Best-Selling Product</h2>
        <?php if ($bestSellingProduct): ?>
            <p><?php echo $bestSellingProduct['name']; ?> (Sold: <?php echo $bestSellingProduct['total_quantity']; ?>)</p>
        <?php else: ?>
            <p>No best-selling product data available.</p>
        <?php endif; ?>

        <h2>Latest Orders</h2>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($latestOrdersResult->num_rows > 0) {
                    $count = 1;
                    while ($order = $latestOrdersResult->fetch_assoc()) {
                        echo "<tr>
                                <td>{$count}</td>
                                <td>{$order['full_name']}</td>
                                <td>{$order['email']}</td>
                                <td>$" . number_format($order['amount'], 2) . "</td>
                                <td>{$order['status']}</td>
                                <td>{$order['order_date']}</td>
                              </tr>";
                        $count++;
                    }
                } else {
                    echo "<tr><td colspan='6'>No recent orders</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </section>
</main>

<?php $conn->close(); ?>

</body>
</html>
