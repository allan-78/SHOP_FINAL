<?php
require_once '../includes/functions/functions.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: index.php");
    exit;
}

function dbConnect() {
    try {
        // Update these values based on your database credentials
        $host = 'localhost'; // Your database host (usually localhost)
        $dbname = 'shoeshop'; // Your database name
        $username = 'root'; // Your database username
        $password = ''; // Your database password (empty for XAMPP by default)

        // Create a PDO instance
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);

        // Set error mode to exception for debugging
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        return $pdo;
    } catch (PDOException $e) {
        // Display error and stop the script
        die('Database connection failed: ' . $e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Update order status
    $orderId = intval($_POST['order_id']);
    $status = $_POST['status'];

    try {
        $db = dbConnect();
        $stmt = $db->prepare("UPDATE orders SET status = :status WHERE id = :id");
        $stmt->execute([':status' => $status, ':id' => $orderId]);

        // Fetch user ID for notification
        $stmt = $db->prepare("SELECT user_id FROM orders WHERE id = :id");
        $stmt->execute([':id' => $orderId]);
        $userId = $stmt->fetchColumn();

        // Create notification
        $message = "Your order #$orderId status has been updated to '$status'.";
        $stmt = $db->prepare("INSERT INTO notifications (user_id, message) VALUES (:user_id, :message)");
        $stmt->execute([':user_id' => $userId, ':message' => $message]);

        echo "<script>alert('Order status updated successfully and user notified!');</script>";
    } catch (PDOException $e) {
        echo "<script>alert('Error updating order status: " . $e->getMessage() . "');</script>";
    }
}

// Fetch recent orders
try {
    $db = dbConnect();
    $stmt = $db->query("
        SELECT o.id, o.user_id, o.created_at, o.status, 
               GROUP_CONCAT(CONCAT(p.name, ' (x', oi.quantity, ')') SEPARATOR ', ') AS items
        FROM orders o
        INNER JOIN order_items oi ON o.id = oi.order_id
        INNER JOIN products p ON oi.product_id = p.product_id
        GROUP BY o.id
        ORDER BY o.created_at DESC
    ");
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('Error fetching orders: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Recent Orders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
       /* Body and font adjustments */
body {
    background-color: #f8f9fa;
    font-family: 'Arial', sans-serif;
}

/* Floating effect for buttons */
.btn-custom, .btn-primary, .btn-secondary {
    font-size: 16px; /* Adjust font size */
    font-weight: bold; /* Make the button text bold */
    letter-spacing: 1px; /* Slightly spaced letters */
    text-transform: uppercase; /* Uppercase text for buttons */
    padding: 10px 20px; /* Adjust padding for a better button size */
    border-radius: 5px;
    transition: all 0.3s ease; /* Smooth transition for hover effects */
    position: relative;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Default shadow */
}

/* Hover effect for floating buttons */
.btn-primary:hover, .btn-custom:hover, .btn-secondary:hover {
    transform: translateY(-5px); /* Move the button up */
    box-shadow: 0 8px 12px rgba(0, 0, 0, 0.2); /* Larger shadow on hover */
}

/* Specific hover styles for each button */
.btn-primary:hover {
    background-color: #0056b3 !important;
    border-color: #004085 !important;
}

.btn-secondary:hover {
    background-color: #5a6268 !important;
    border-color: #4e555b !important;
}

.btn-custom:hover {
    background-color: #218838 !important;
    border-color: #1e7e34 !important;
}

/* Hover effect for table rows */
table tbody tr {
    transition: transform 0.3s ease, box-shadow 0.3s ease; /* Smooth transition for rows */
}

/* Hover effect for table rows */
table tbody tr:hover {
    transform: translateY(-5px); /* Rows move up slightly on hover */
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Add a shadow to rows on hover */
    background-color: #f1f1f1; /* Light background color on hover for visibility */
}

/* Additional styling for the table and items */
.order-items {
    font-size: 0.9em;
    color: #6c757d;
}

/* Style for badges */
.badge {
    font-size: 0.875em;
}

/* General container and layout */
.container {
    margin-top: 50px;
}

    </style>
</head>
<body>
    <div class="container">
        <h1 class="mb-4">Recent Orders</h1>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>User ID</th>
                    <th>Items</th>
                    <th>Order Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($orders)): ?>
                    <tr>
                        <td colspan="6" class="text-center">No recent orders found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?php echo $order['id']; ?></td>
                            <td><?php echo $order['user_id']; ?></td>
                            <td class="order-items"><?php echo htmlspecialchars($order['items']); ?></td>
                            <td><?php echo $order['created_at']; ?></td>
                            <td>
                                <span class="badge bg-<?php echo $order['status'] == 'completed' ? 'success' : ($order['status'] == 'shipped' ? 'primary' : 'warning'); ?>">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </td>
                            <td>
                                <form method="post" class="d-inline">
                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                    <select name="status" class="form-select form-select-sm d-inline-block w-auto">
                                        <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                        <option value="shipped" <?php echo $order['status'] == 'shipped' ? 'selected' : ''; ?>>Shipped</option>
                                        <option value="completed" <?php echo $order['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                    </select>
                                    <button type="submit" class="btn btn-sm btn-primary">Update</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
       
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
