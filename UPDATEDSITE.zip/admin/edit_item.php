<?php
require_once '../includes/functions/functions.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: index.php");
    exit;
}

// Fetch categories from the database
$categories = getCategories();  // Fetch all categories

$id = $_GET['id'];
$product = getProductById($id); // Get product details

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle form submission and update the product in the database
    $name = $_POST['name'];
    $description = $_POST['description'];
    $category_id = $_POST['category_id']; // Get the selected category ID
    $price = $_POST['price'];
    $image = $_FILES['image']['name'];

    // Handle image upload if a new image is selected
    if ($_FILES['image']['error'] == 0) {
        $target_dir = "../uploads/products/";
        $target_file = $target_dir . basename($image);
        move_uploaded_file($_FILES['image']['tmp_name'], $target_file);
    } else {
        // Keep existing image if no new image is uploaded
        $image = $product['image'];
    }

    // Call updateProduct function with necessary parameters
    if (updateProduct($id, $name, $description, $category_id, $price, $image)) {
        header("Location: items.php"); // Redirect to items page after update
        exit;
    } else {
        echo "<p class='text-danger'>Error updating the product. Please try again later.</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Edit Shoe</title>
    <link rel="stylesheet" href="../layout/css/admin.css">
    <!-- Bootstrap CDN for styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1>Edit Shoe</h1>
        <form method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="name" class="form-label">Name:</label>
                <input type="text" id="name" name="name" value="<?php echo $product['name']; ?>" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Description:</label>
                <textarea id="description" name="description" class="form-control" required><?php echo $product['description']; ?></textarea>
            </div>

            <div class="mb-3">
                <label for="category" class="form-label">Category:</label>
                <select id="category" name="category_id" class="form-control" required>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>" <?php if ($category['id'] == $product['category_id']) echo 'selected'; ?>>
                            <?php echo $category['name']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="price" class="form-label">Price:</label>
                <input type="number" id="price" name="price" value="<?php echo $product['price']; ?>" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="image" class="form-label">Image:</label>
                <input type="file" id="image" name="image" class="form-control" accept="image/*">
                <?php if (!empty($product['image'])): ?>
                    <img src="uploads/products/<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" width="100">
                <?php endif; ?>
            </div>

            <button type="submit" class="btn btn-primary">Update Product</button>
        </form>
        <a href="items.php" class="btn btn-secondary">Back to Inventory</a>
        <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
