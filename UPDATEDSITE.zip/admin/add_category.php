<?php
require_once '../includes/functions/functions.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: index.php");
    exit;
}

// Initialize error/success messages
$error = '';
$success = '';

function dbConnect() {
    try {
        // Update these values based on your database credentials
        $host = 'localhost'; // Your database host (usually localhost)
        $dbname = 'shoeshop'; // Your database name
        $username = 'root'; // Your database username
        $password = ''; // Your database password (empty for XAMPP by default)

        // Create a PDO instance
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);

        // Set error mode to exception for debugging
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        return $pdo;
    } catch (PDOException $e) {
        // Display error and stop the script
        die('Database connection failed: ' . $e->getMessage());
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form inputs
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);

    // Validate inputs
    if (empty($name)) {
        $error = 'Category name is required.';
    } else {
        // Add the new category to the database
        try {
            $db = dbConnect(); // Assumes dbConnect() is defined in your functions.php
            $stmt = $db->prepare("INSERT INTO categories (name, description) VALUES (:name, :description)");
            $stmt->bindParam(':name', $name, PDO::PARAM_STR);
            $stmt->bindParam(':description', $description, PDO::PARAM_STR);
            $stmt->execute();

            $success = 'Category added successfully!';
        } catch (PDOException $e) {
            $error = 'Failed to add category: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Add New Category</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
     /* Body and font adjustments */
body {
    background-color: #f8f9fa;
    font-family: 'Arial', sans-serif;
}

.btn-custom, .btn-primary, .btn-secondary {
    font-size: 16px; /* Adjust font size */
    font-weight: bold; /* Make the button text bold */
    letter-spacing: 1px; /* Slightly spaced letters */
    text-transform: uppercase; /* Uppercase text for buttons */
    padding: 10px 20px; /* Adjust padding for a better button size */
    border-radius: 5px;
    transition: all 0.3s ease; /* Smooth transition for hover effects */
}

/* Hover effect for floating buttons */
.btn-primary, .btn-custom, .btn-secondary {
    position: relative;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Default shadow */
}

/* Add floating effect on hover */
.btn-primary:hover, .btn-custom:hover, .btn-secondary:hover {
    background-color: #0056b3; /* For btn-primary */
    border-color: #004085; /* For btn-primary */
    transform: translateY(-5px); /* Move the button up */
    box-shadow: 0 8px 12px rgba(0, 0, 0, 0.2); /* Larger shadow on hover */
}

/* Adjust specific button hover effects */
.btn-primary:hover {
    background-color: #0056b3 !important;
    border-color: #004085 !important;
}

.btn-secondary:hover {
    background-color: #5a6268 !important;
    border-color: #4e555b !important;
}

.btn-custom:hover {
    background-color: #218838 !important;
    border-color: #1e7e34 !important;
}

/* Back Links Styling */
.back-links {
    margin-top: 30px;
    display: flex;
    gap: 15px;
    justify-content: flex-start;
}

    </style>
</head>
<body>
    <div class="container">
        <h1 class="mb-4 text-center">Add New Category</h1>

        <!-- Display error/success messages -->
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if (!empty($success)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <!-- Category form -->
        <form method="post" class="shadow p-4 bg-white rounded">
            <div class="mb-3">
                <label for="name" class="form-label">Category Name</label>
                <input type="text" id="name" name="name" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea id="description" name="description" class="form-control"></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Add Category</button>

            <div class="back-links">
                <a href="categories.php" class="btn btn-secondary">Back to Categories</a>
                <a href="dashboard.php" class="btn btn-custom">Back to Dashboard</a>
            </div>
        </form>
    </div>

    <!-- Bootstrap JavaScript Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
