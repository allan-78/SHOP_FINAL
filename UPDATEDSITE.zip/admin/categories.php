<?php
require_once '../includes/functions/functions.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: index.php");
    exit;
}

// Get categories from the database
$categories = getCategories();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Categories</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .table {
            background-color: #ffffff;
        }
        .btn {
            margin-right: 5px;
            transition: all 0.3s ease;
            padding: 10px 20px; /* Ensure both buttons are the same size */
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .header .btn-group {
            display: flex;
            gap: 15px; /* Add space between buttons */
        }
        .dashboard-btn {
            background-color: #007bff;
            color: white;
            text-decoration: none;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .dashboard-btn:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }
        .btn-sm {
            font-size: 0.9em;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .table-responsive {
            margin-top: 20px;
        }

        /* Hover Effects for Table Buttons */
        .btn-sm:hover {
            transform: scale(1.05);
        }
        .btn-warning:hover {
            background-color: #e0a800;
        }
        .btn-danger:hover {
            background-color: #d32f2f;
        }

        /* Hover Effects for Category Actions */
        .table .btn:hover {
            transition: transform 0.3s ease, background-color 0.3s ease;
        }

        /* Adjusting Button Layout */
        .header .btn-group {
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .header .add-category-btn {
            margin-left: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Categories</h1>
            <div class="btn-group">
                <a href="dashboard.php" class="dashboard-btn btn">Go to Dashboard</a>
                <a href="add_category.php" class="btn btn-primary btn-sm add-category-btn">Add New Category</a>
            </div>
        </div>

        <?php if (!empty($categories)): ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($categories as $category): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($category['id']); ?></td>
                                <td><?php echo htmlspecialchars($category['name']); ?></td>
                                <td>
                                    <a href="edit_category.php?id=<?php echo $category['id']; ?>" class="btn btn-warning btn-sm">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <a href="delete_category.php?id=<?php echo $category['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this category?')">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-center">No categories found. <a href="add_category.php">Add one now!</a></p>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JavaScript Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
