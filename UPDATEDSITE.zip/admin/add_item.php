<?php
require_once '../includes/functions/functions.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: index.php");
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect and sanitize form data
    $name = htmlspecialchars(trim($_POST['name']));
    $description = htmlspecialchars(trim($_POST['description']));
    $category_id = intval($_POST['category_id']);
    $price = floatval($_POST['price']);
    $gender = htmlspecialchars(trim($_POST['gender']));
    $age_group = htmlspecialchars(trim($_POST['age_group']));
    $size = htmlspecialchars(trim($_POST['size']));
    $color = htmlspecialchars(trim($_POST['color']));
    $rating = floatval($_POST['rating']);

    // Handle image upload
    $image = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $imageTmpPath = $_FILES['image']['tmp_name'];
        $imageName = $_FILES['image']['name'];
        $imageSize = $_FILES['image']['size'];
        $imageType = $_FILES['image']['type'];

        // Validate image type and size (optional)
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (in_array($imageType, $allowedTypes) && $imageSize <= 5 * 1024 * 1024) { // 5MB max
            $imagePath = '../uploads/products/' . $imageName;
            move_uploaded_file($imageTmpPath, $imagePath);
            $image = $imageName;
        } else {
            $error = 'Invalid image file. Only JPEG, PNG, GIF allowed and max size 5MB.';
        }
    }

    // Insert product into the database
    if (!isset($error)) {
        $query = "INSERT INTO products (name, description, category_id, price, image, gender, age_group, size, color, rating) 
                  VALUES ('$name', '$description', '$category_id', '$price', '$image', '$gender', '$age_group', '$size', '$color', '$rating')";

        if ($conn->query($query) === TRUE) {
            $success = 'Product added successfully!';
        } else {
            $error = 'Error adding product: ' . $conn->error;
        }
    }
}

// Get categories for the select dropdown
$categories = getCategories();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Add New Shoe</title>
    <!-- Bootstrap 4 CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f4f7f6;
            font-family: 'Arial', sans-serif;
        }

        .container {
            max-width: 900px;
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }

        h1 {
            font-size: 30px;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
        }

        .form-control {
            border-radius: 8px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            font-weight: bold;
            transition: background-color 0.3s, transform 0.3s;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
            transform: scale(1.05);
        }

        .btn-secondary, .btn-danger {
            font-weight: bold;
            padding: 10px 20px;
            transition: background-color 0.3s, transform 0.3s;
        }

        .btn-secondary:hover {
            background-color: #6c757d;
            transform: scale(1.05);
        }

        .btn-danger:hover {
            background-color: #d32f2f;
            transform: scale(1.05);
        }

        .alert {
            border-radius: 8px;
            font-size: 16px;
            margin-bottom: 20px;
        }

        .back-links {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
        }

        .dashboard-btn {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .dashboard-btn:hover {
            background-color: #218838;
            transform: scale(1.05);
        }

        .form-row .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: bold;
        }

        .form-group select, .form-group input, .form-group textarea {
            border-radius: 8px;
            padding: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Add New Shoe</h1>

        <!-- Display success or error messages -->
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php elseif (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Product Form -->
        <form method="post" enctype="multipart/form-data">
            <div class="form-row">
                <!-- Name Input -->
                <div class="form-group col-md-6">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" class="form-control" required>
                </div>

                <!-- Price Input -->
                <div class="form-group col-md-6">
                    <label for="price">Price:</label>
                    <input type="number" id="price" name="price" class="form-control" required step="0.01">
                </div>
            </div>

            <div class="form-row">
                <!-- Description Input -->
                <div class="form-group col-md-12">
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" class="form-control" rows="4"></textarea>
                </div>
            </div>

            <div class="form-row">
                <!-- Category Select -->
                <div class="form-group col-md-6">
                    <label for="category">Category:</label>
                    <select id="category" name="category_id" class="form-control" required>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo $category['id']; ?>"><?php echo $category['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <!-- Gender Select (Radio Buttons) -->
                <div class="form-group col-md-6">
                    <label>Gender:</label><br>
                    <label for="gender_male">
                        <input type="radio" id="gender_male" name="gender" value="Male" required> Male
                    </label>
                    <label for="gender_female" class="ml-3">
                        <input type="radio" id="gender_female" name="gender" value="Female" required> Female
                    </label>
                </div>

                <!-- Age Group Select -->
                <div class="form-group col-md-6">
                    <label for="age_group">Age Group:</label>
                    <select id="age_group" name="age_group" class="form-control" required>
                        <option value="Kids">Kids</option>
                        <option value="Teens">Teens</option>
                        <option value="Adults">Adults</option>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <!-- Size Select -->
                <div class="form-group col-md-6">
                    <label for="size">Size:</label>
                    <select id="size" name="size" class="form-control" required>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                    </select>
                </div>

                <!-- Color Select -->
                <div class="form-group col-md-6">
                    <label for="color">Color:</label>
                    <select id="color" name="color" class="form-control" required>
                        <option value="Black">Black</option>
                        <option value="White">White</option>
                        <option value="Red">Red</option>
                        <option value="Blue">Blue</option>
                        <option value="Green">Green</option>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <!-- Rating Select -->
                <div class="form-group col-md-6">
                    <label for="rating">Rating:</label>
                    <select id="rating" name="rating" class="form-control" required>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>

                <!-- Image Upload -->
                <div class="form-group col-md-6">
                    <label for="image">Image:</label>
                    <input type="file" id="image" name="image" class="form-control-file" accept="image/*">
                </div>
            </div>

            <!-- Submit Button -->
            <div class="form-row">
                <div class="col-md-12 text-center">
                    <button type="submit" class="btn btn-primary">Add Product</button>
                </div>
            </div>
        </form>

        <!-- Back to Inventory and Dashboard Links -->
        <div class="back-links">
            <a href="items.php" class="btn btn-secondary">Back to Inventory</a>
            <a href="dashboard.php" class="btn dashboard-btn">Go to Dashboard</a>
        </div>
    </div>

    <!-- Bootstrap JS (Bundle) -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
