<?php
require_once '../includes/functions/functions.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: index.php");
    exit;
}
function dbConnect() {
    try {
        // Update these values based on your database credentials
        $host = 'localhost'; // Your database host (usually localhost)
        $dbname = 'shoeshop'; // Your database name
        $username = 'root'; // Your database username
        $password = ''; // Your database password (empty for XAMPP by default)

        // Create a PDO instance
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);

        // Set error mode to exception for debugging
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        return $pdo;
    } catch (PDOException $e) {
        // Display error and stop the script
        die('Database connection failed: ' . $e->getMessage());
    }
}
// Get category ID from query string
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch category details
$category = getCategoryById($id);

if (!$category) {
    echo "<script>alert('Category not found!'); window.location.href = 'categories.php';</script>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $db = dbConnect();
        $stmt = $db->prepare("DELETE FROM Categories WHERE id = :id");
        $stmt->execute([':id' => $id]);

        echo "<script>alert('Category deleted successfully!'); window.location.href = 'categories.php';</script>";
        exit;
    } catch (PDOException $e) {
        echo "<script>alert('Error deleting category: " . $e->getMessage() . "');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Delete Category</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 100px;
            max-width: 600px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="container text-center">
        <h1 class="mb-4">Delete Category</h1>
        <p class="lead">Are you sure you want to delete <strong>"<?php echo htmlspecialchars($category['name']); ?>"</strong>?</p>
        <form method="post">
            <div class="d-flex justify-content-center gap-3">
                <button type="submit" class="btn btn-danger">Delete</button>
                <a href="categories.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
        <div class="mt-4">
            <a href="logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
