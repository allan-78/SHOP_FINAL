/* admin_style.css */

/* Sidebar Styles */
<style>
/* admin_style.css */

/* Sidebar Styles */
.sidebar {
    height: 100vh;
    width: 250px;
    background-color: #2C3E50;
    padding-top: 20px;
    position: fixed;
    top: 0;
    left: 0;
    transition: width 0.3s ease;
}

.sidebar .logo {
    font-size: 1.5em;
    color: white;
    text-align: center;
    margin-bottom: 20px;
    padding: 10px;
}

.sidebar a {
    display: block;
    padding: 15px;
    text-decoration: none;
    color: white;
    font-size: 1.1em;
    margin: 10px 0;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.sidebar a:hover {
    background-color: #34495E;
}

.sidebar a.active {
    background-color: #1ABC9C;
}

/* Button to toggle sidebar visibility */
.toggle-btn {
    position: absolute;
    top: 20px;
    right: -30px;
    background-color: #2C3E50;
    color: white;
    padding: 10px;
    border: none;
    cursor: pointer;
    border-radius: 50%;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
}

.toggle-btn:hover {
    background-color: #34495E;
}

/* Main content styling (to offset sidebar) */
.main-content {
    margin-left: 250px;
    padding: 20px;
    transition: margin-left 0.3s ease;
}

/* Search bar */
.search {
    margin-bottom: 20px;
}

.search input {
    padding: 10px;
    width: 100%;
    border-radius: 5px;
    border: 1px solid #ccc;
}

/* Media Query for Smaller Screens */
@media (max-width: 768px) {
    /* Sidebar becomes smaller on small screens */
    .sidebar {
        width: 200px;
    }

    /* Main content shifts accordingly */
    .main-content {
        margin-left: 200px;
    }

    /* Reduce font size in sidebar for small screens */
    .sidebar a {
        font-size: 1em;
    }
}

@media (max-width: 480px) {
    /* Sidebar collapses on very small screens */
    .sidebar {
        width: 0;
        visibility: hidden;
    }

    /* Main content margin becomes 0 when sidebar is hidden */
    .main-content {
        margin-left: 0;
    }
}

</style>