<!-- templates/admin_header.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet"> <!-- Font Awesome Icons -->
    <style>
       /* Sidebar Styling */
       .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            padding-top: 15px; /* Reduced padding */
            color: #fff;
            overflow: hidden;
        }

        .sidebar a {
            padding: 8px 16px; /* Reduced padding */
            text-decoration: none;
            font-size: 1em; /* Slightly smaller font size */
            display: block;
            color: #fff;
            margin-bottom: 8px; /* Reduced margin */
            border-radius: 5px;
        }

        .sidebar a:hover {
            background-color: #f1f1f1; /* Light gray */
            color: #343a40; /* Dark text color for contrast */
            transform: translateY(-5px); /* Floating effect */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow effect */
        }

        .sidebar .logo {
            font-size: 1.4em; /* Slightly smaller logo font size */
            font-weight: bold;
            text-align: center;
            margin-bottom: 25px; /* Reduced margin */
            transition: transform 0.3s ease; /* Smooth transition */
        }

        .sidebar .logo:hover {
            transform: translateY(-10px) scale(1.1); /* Move and slightly scale up the logo */
        }

        .nav-link {
            font-size: 0.9rem; /* Slightly smaller font size */
            color: #ddd;
            padding: 6px 10px; /* Reduced padding */
            text-decoration: none;
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        }

        .nav-link:hover {
            background-color: #f1f1f1; /* Light gray background */
            color: #343a40; /* Dark text color for contrast */
            border-radius: 5px;
            transform: translateY(-5px); /* Makes the link float */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Adds a shadow for floating effect */
        }

        .nav-link.active {
            background-color: #0056b3;
            color: white;
        }

        .sidebar .nav-item {
            margin-bottom: 5px; /* Reduced bottom margin */
        }

        /* Search bar styling */
        .search-bar-container {
            display: flex;
            justify-content: flex-end;
            margin: 6px 10px; /* Reduced margin */
        }

        .search-bar-container input {
            width: 210px; /* Adjusted width */
            padding: 5px 8px; /* Reduced padding */
            border-radius: 5px;
            border: 1px solid #ddd;
            font-size: 0.85rem; /* Smaller font size */
        }

        /* Main Content Section */
        .main-content {
            margin-left: 250px;
            padding: 8px 12px; /* Reduced padding */
        }

        /* For smaller screens (Responsive) */
        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }

            .main-content {
                margin-left: 0;
            }
        }

        /* Logout Link Hover Effect */
        .nav-link.logout:hover {
            background-color: #dc3545; /* Red color */
            color: white;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="logo">
        Admin Dashboard
    </div>

    <!-- Navigation links -->
    <nav class="nav flex-column">
        <a href="dashboard.php" class="nav-link"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="members.php" class="nav-link"><i class="fas fa-users"></i> Manage Users</a>
        <a href="items.php" class="nav-link"><i class="fas fa-box"></i> Manage Products</a>
        <a href="categories.php" class="nav-link"><i class="fas fa-tags"></i> Manage Categories</a>
        <a href="return_management.php" class="nav-link"><i class="fas fa-undo"></i> Manage Refund</a>
        <a href="add_item.php" class="nav-link"><i class="fas fa-plus-circle"></i> Add Product</a>
        <a href="add_category.php" class="nav-link"><i class="fas fa-plus-square"></i> Add Category</a>
        <a href="add_user.php" class="nav-link"><i class="fas fa-user-plus"></i> Add User</a>
        <a href="comments.php" class="nav-link"><i class="fas fa-comment-dots"></i> Product Reviews</a>
        <a href="recent_orders.php" class="nav-link"><i class="fas fa-clipboard-list"></i> Recent Orders</a>
        <a href="logout.php" class="nav-link logout text-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>
</div>

<!-- Main Content Section -->
<div class="main-content">
    <div class="container">
        <!-- Search bar container -->
        <div class="search-bar-container">
            <input type="text" placeholder="Search...">
        </div>
        
        <h2>Welcome to the Admin Dashboard</h2>
        <p>Manage your site from here.</p>
        <!-- Additional content goes here -->
    </div>
</div>

<!-- Bootstrap JS (No jQuery or Popper.js needed here) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

</body>
</html>
