<?php
require_once '../includes/functions/functions.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: index.php");
    exit;
}

$id = $_GET['id'];
$user = getUserById($id);

// Fetch available roles and statuses (you can customize this as needed)
$roles = ['admin', 'user']; // Example roles
$statuses = ['active', 'inactive']; // Example statuses

// Handle form submission to update user details
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form input values
    $username = $_POST['username'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $status = $_POST['status'];

    // Update the user in the database
    updateUser($id, $username, $email, $role, $status);

    // Redirect to members page after update
    header("Location: members.php");
    exit;
}

// Database function to fetch a user by ID
function getUserById($id) {
    $conn = connectDB(); // Ensure you have a proper DB connection function
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

// Database function to update user details
function updateUser($id, $username, $email, $role, $status) {
    $conn = connectDB();
    $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, role = ?, status = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $username, $email, $role, $status, $id);
    $stmt->execute();
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Edit User</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Jg6U8fxtmDDg98qr0wL2YN9y09z77+mMGwvhxdT05/oZ2rcHg8VcsreRrGZ7kV00" crossorigin="anonymous">
    <link rel="stylesheet" href="../layout/css/admin.css">
    <style>
        /* Additional CSS to make the page more professional */
        body {
            background-color: #f4f7fc;
            font-family: 'Arial', sans-serif;
        }
        .container {
            max-width: 900px;
            margin-top: 40px;
        }
        .form-label {
            font-weight: 600;
        }
        .form-control, .form-select {
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
        }
        .btn-info, .btn-secondary {
            margin-right: 10px;
            border-radius: 8px;
        }
        .card {
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .profile-img {
            border-radius: 50%;
            width: 150px;
            height: 150px;
            object-fit: cover;
            margin-bottom: 20px;
        }
        .default-profile-img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background-color: #ddd;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 36px;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mb-4 text-center">Edit User</h1>

        <div class="card p-4">
            <div class="row">
                <!-- Display Profile Image or Default Profile -->
                <div class="col-md-4 text-center">
                    <?php if (empty($user['profile_pic'])): ?>
                        <div class="default-profile-img">
                            <span><?php echo strtoupper(substr($user['username'], 0, 1)); ?></span>
                        </div>
                    <?php else: ?>
                        <img src="../uploads/profile_pics/<?php echo $user['profile_pic']; ?>" alt="Profile Image" class="profile-img">
                    <?php endif; ?>
                </div>
                <!-- Edit User Form -->
                <div class="col-md-8">
                    <form method="post">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username:</label>
                            <input type="text" id="username" name="username" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>

                        <!-- Role Dropdown -->
                        <div class="mb-3">
                            <label for="role" class="form-label">Role:</label>
                            <select id="role" name="role" class="form-select" required>
                                <?php foreach ($roles as $roleOption): ?>
                                    <option value="<?php echo $roleOption; ?>" <?php echo ($user['role'] == $roleOption) ? 'selected' : ''; ?>>
                                        <?php echo ucfirst($roleOption); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Status Dropdown -->
                        <div class="mb-3">
                            <label for="status" class="form-label">Status:</label>
                            <select id="status" name="status" class="form-select" required>
                                <?php foreach ($statuses as $statusOption): ?>
                                    <option value="<?php echo $statusOption; ?>" <?php echo ($user['status'] == $statusOption) ? 'selected' : ''; ?>>
                                        <?php echo ucfirst($statusOption); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary">Update User</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="mt-3">
            <a href="members.php" class="btn btn-secondary">Back to User Accounts</a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz4fnFO9gyb7fFjsLg4v6fh4A6hK6G5I2LfG8hz6j6aR1Bz5dpF8RjVKkSF" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0v8Fq69uo8pCspHq3nnQUxz8Ac/gj6QldgHLO88ZXfHniYFb" crossorigin="anonymous"></script>
</body>
</html>
