<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - EM' Quality Shoes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f2f2f2;
        }
        .login-container {
            background-color: #fff;
            padding: 40px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 100px auto;
            max-width: 400px;
        }
        .small-link {
            font-size: 0.9em;
            text-align: center;
            margin-top: 15px;
        }
        .small-link a {
            color: #007bff;
            text-decoration: none;
        }
        .small-link a:hover {
            text-decoration: underline;
        }

        /* Button hover effect */
        .btn-hover-effect {
            transition: all 0.3s ease; /* Smooth transition for all properties */
        }

        .btn-hover-effect:hover {
            transform: translateY(-5px); /* Moves the button upwards */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Adds shadow for the floating effect */
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="login-container">
                <h2 class="text-center mb-4">Admin Login</h2>
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                <form method="POST">
                    <div class="form-group">
                        <label for="username">Username:</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block btn-hover-effect" name="login">Login</button>
                </form>

                <!-- Small link for redirect -->
                <div class="small-link">
                    <a href="../login.php">Back to login page</a>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
