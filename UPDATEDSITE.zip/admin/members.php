<?php
// Include the necessary functions and start session
require_once('../includes/functions/functions.php');
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: index.php"); // Redirect to login if not an admin
    exit;
}

// Fetch all users from the database
$users = getUsers();

// Database function to fetch users
function getUsers() {
    $conn = connectDB(); // Ensure you have a proper DB connection function
    $sql = "SELECT * FROM users"; // Adjust table name if necessary
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC); // Fetch all users as an associative array
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - User Accounts</title>
    <link rel="stylesheet" href="../layout/css/admin.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        th, td {
            padding: 6px; /* Reduced padding */
            text-align: center;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            margin: 10px 5px;
            transition: background-color 0.3s, transform 0.2s;
        }
        .btn:hover {
            background-color: #0056b3;
            transform: translateY(-3px); /* Hover animation */
        }
        .btn-danger {
            background-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
        .space-below {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>

    <div class="container">
        <!-- Go to Dashboard Button -->
        <div class="space-below">
            <a href="dashboard.php" class="btn">Go to Dashboard</a>
        </div>

        <h1>User Accounts</h1>
        
        <!-- User Table -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($users) > 0): ?>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo $user['id']; ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo ucfirst($user['role']); ?></td> <!-- Display role -->
                            <td><?php echo ucfirst($user['status']); ?></td> <!-- Display status -->
                            <td class="actions">
                                <!-- Edit User -->
                                <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn">Edit</a>

                                <!-- Delete User -->
                                <a href="delete_user.php?id=<?php echo $user['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No users found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Additional Actions -->
        <div class="actions">
            <a href="add_user.php" class="btn">Add New User</a>
            <a href="dashboard.php" class="btn">Go to Dashboard</a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </div>

</body>
</html>
