<?php
session_start();
require_once 'includes/functions/functions.php';

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // Get the user ID from the session

// Database connection
try {
    if (!isset($pdo)) {
        $pdo = new PDO("mysql:host=localhost;dbname=shoeshop", "root", "");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
} catch (PDOException $e) {
    echo "Database connection failed: " . $e->getMessage();
    exit();
}

// Check if a review ID is passed
if (!isset($_GET['review_id'])) {
    echo "Invalid request. No review ID provided.";
    exit();
}

$review_id = $_GET['review_id'];

// Fetch the current review details
try {
    $sql_review = "SELECT r.*, p.name AS product_name 
                   FROM reviews r 
                   JOIN products p ON r.product_id = p.product_id 
                   WHERE r.id = :review_id AND r.user_id = :user_id";
    $stmt_review = $pdo->prepare($sql_review);
    $stmt_review->execute(['review_id' => $review_id, 'user_id' => $user_id]);
    $review = $stmt_review->fetch(PDO::FETCH_ASSOC);

    if (!$review) {
        echo "Review not found or you are not authorized to edit this review.";
        exit();
    }
} catch (PDOException $e) {
    echo "Error fetching review: " . $e->getMessage();
    exit();
}

// Handle review update form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $updated_review_text = trim($_POST['review_text']);
    $updated_rating = (int) $_POST['rating'];

    // Validate inputs
    if (empty($updated_review_text) || $updated_rating < 1 || $updated_rating > 5) {
        $error_message = "Review text cannot be empty, and rating must be between 1 and 5.";
    } else {
        // Update the review in the database
        try {
            $sql_update = "UPDATE reviews 
                           SET review_text = :review_text, 
                               rating = :rating, 
                               updated_at = NOW() 
                           WHERE id = :review_id AND user_id = :user_id";
            $stmt_update = $pdo->prepare($sql_update);
            $stmt_update->execute([
                'review_text' => $updated_review_text,
                'rating' => $updated_rating,
                'review_id' => $review_id,
                'user_id' => $user_id
            ]);
            $success_message = "Review updated successfully!";
        } catch (PDOException $e) {
            $error_message = "Error updating review: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Review | EM' Quality Shoes</title>
    <link rel="stylesheet" href="layout/css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background-color: #fff;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .container h2 {
            font-size: 1.8rem;
            margin-bottom: 20px;
            text-align: center;
        }
        .form-group label {
            font-size: 1rem;
            font-weight: bold;
        }
        .btn {
            display: block;
            width: 100%;
            margin-top: 20px;
        }
        .error-message, .success-message {
            text-align: center;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .error-message {
            background-color: #f8d7da;
            color: #721c24;
        }
        .success-message {
            background-color: #d4edda;
            color: #155724;
        }
        .redirect-btn {
            margin-top: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
<?php include 'templates/header.php'; ?>
<div class="container">
    <h2>Update Your Review</h2>

    <!-- Display error or success message -->
    <?php if (isset($error_message)): ?>
        <div class="error-message"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <?php if (isset($success_message)): ?>
        <div class="success-message"><?php echo $success_message; ?></div>
        <div class="redirect-btn">
            <a href="my_reviews.php" class="btn btn-primary">Go Back to My Reviews</a>
        </div>
    <?php endif; ?>

    <!-- Review update form -->
    <?php if (!isset($success_message)): ?>
    <form method="post" action="update_reviews.php?review_id=<?php echo htmlspecialchars($review_id); ?>">
        <div class="form-group">
            <label>Product Name:</label>
            <p><strong><?php echo htmlspecialchars($review['product_name']); ?></strong></p>
        </div>

        <div class="form-group">
            <label for="rating">Rating (1 to 5):</label>
            <input type="number" id="rating" name="rating" class="form-control" value="<?php echo htmlspecialchars($review['rating']); ?>" min="1" max="5" required>
        </div>

        <div class="form-group">
            <label for="review_text">Review Text:</label>
            <textarea id="review_text" name="review_text" class="form-control" rows="5" required><?php echo htmlspecialchars($review['review_text']); ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Update Review</button>
    </form>
    <?php endif; ?>
</div>

</body>
</html>
