<?php
require_once 'includes/functions/functions.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

try {
    // Create a PDO connection to fetch the ordered items
    if (!isset($pdo)) {
        $pdo = new PDO("mysql:host=localhost;dbname=shoeshop", "root", "");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    // Fetch the orders and related products for the logged-in user
    $sql = "SELECT oi.id AS order_item_id, oi.product_id, oi.quantity, oi.price, o.status, p.name AS product_name
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.id
            JOIN products p ON oi.product_id = p.product_id
            WHERE o.user_id = :user_id";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['user_id' => $user_id]);
    $orderedItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ordered Items - EmShoe</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }
        .navbar {
            margin-bottom: 20px;
        }
        .ordered-items {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .table th, .table td {
            text-align: center;
            vertical-align: middle;
        }
        .review-btn button {
            background-color: #007bff;
            border: none;
            color: #fff;
            padding: 8px 12px;
            border-radius: 20px;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        .review-btn button:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }
        .no-items {
            text-align: center;
            font-size: 1.2rem;
            color: #6c757d;
        }
    </style>
</head>
<body>
<?php include 'templates/header.php'; ?>
<div class="container">
    <div class="ordered-items">
        <h2 class="text-center mb-4">Your Ordered Items</h2>

        <?php if (!empty($orderedItems)): ?>
            <table class="table table-bordered table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Review</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orderedItems as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td><?php echo $item['price']; ?></td>
                            <td>
                                <?php 
                                    // Display product status
                                    echo ucfirst($item['status']);
                                ?>
                            </td>
                            <td>
                                <?php
                                    // Check if the user has already reviewed the product using product_id and user_id
                                    $checkReviewSql = "SELECT COUNT(*) FROM reviews
                                                        WHERE product_id = :product_id AND user_id = :user_id";
                                    $reviewStmt = $pdo->prepare($checkReviewSql);
                                    $reviewStmt->execute([
                                        'product_id' => $item['product_id'],
                                        'user_id' => $user_id
                                    ]);
                                    $hasReviewed = $reviewStmt->fetchColumn() > 0;

                                    if (!$hasReviewed && $item['status'] === 'shipped'): ?>
                                        <form method="GET" action="review_product.php" class="review-btn">
                                            <input type="hidden" name="order_item_id" value="<?php echo $item['order_item_id']; ?>">
                                            <input type="hidden" name="product_id" value="<?php echo $item['product_id']; ?>">
                                            <button type="submit">Write Review</button>
                                        </form>
                                    <?php elseif ($hasReviewed): ?>
                                        <span class="text-success">Reviewed</span>
                                        <?php
                                            // Update the order status to 'completed' once the review is done
                                            $updateStatusSql = "UPDATE orders SET status = 'completed' 
                                                                WHERE id = (SELECT order_id FROM order_items WHERE id = :order_item_id)";
                                            $updateStmt = $pdo->prepare($updateStatusSql);
                                            $updateStmt->execute(['order_item_id' => $item['order_item_id']]);
                                        ?>
                                    <?php else: ?>
                                        <span class="text-muted">Pending</span>
                                    <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="no-items">No orders found.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
