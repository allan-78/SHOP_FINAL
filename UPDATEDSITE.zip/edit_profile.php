<?php
include('includes/functions/functions.php'); // Assuming your PDO connection and functions are here

// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details from the database
$stmt = $pdo->prepare("SELECT * FROM Users WHERE id = :user_id");
$stmt->execute(['user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Default profile picture if none is set
$profile_picture = $user['profile_picture'] ? $user['profile_picture'] : 'uploads/profile_pics/default.jpg';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle file upload if a new profile picture is selected
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        // Define the upload directory and file name
        $upload_dir = 'uploads/profile_pics/';
        $filename = $_FILES['profile_picture']['name'];
        $file_tmp = $_FILES['profile_picture']['tmp_name'];
        $file_path = $upload_dir . basename($filename);

        // Move the uploaded file to the desired directory
        if (move_uploaded_file($file_tmp, $file_path)) {
            // Update the profile picture in the database
            $stmt = $pdo->prepare("UPDATE Users SET profile_picture = :profile_picture WHERE id = :user_id");
            $stmt->execute([
                'profile_picture' => $file_path,
                'user_id' => $user_id
            ]);
            $profile_picture = $file_path; // Update the profile picture variable
        } else {
            echo "Error uploading the file.";
        }
    }

    // Update other user details
    $stmt = $pdo->prepare("UPDATE Users SET first_name = :first_name, last_name = :last_name, email = :email WHERE id = :user_id");
    $stmt->execute([
        'first_name' => $_POST['first_name'],
        'last_name' => $_POST['last_name'],
        'email' => $_POST['email'],
        'user_id' => $user_id
    ]);

    header("Location: profile.php"); // Redirect to profile after update
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .container h2 {
            color: #3f51b5;
            text-align: center;
            margin-bottom: 20px;
        }

        .profile-img {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            object-fit: cover;
            display: block;
            margin: 0 auto 20px auto;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        footer {
            background-color: #3f51b5;
            color: white;
            text-align: center;
            padding: 15px 0;
            margin-top: 40px;
        }
    </style>
</head>
<body>
    <?php include 'templates/header.php'; ?>

    <div class="container mt-5">
        <h2>Edit Profile</h2>
        <form action="edit_profile.php" method="POST" enctype="multipart/form-data">
            <div class="form-group text-center">
                <label for="profile_picture">Profile Picture</label><br>
                <img src="<?php echo $profile_picture; ?>" alt="Profile Picture" class="profile-img">
            </div>
            <div class="form-group">
                <label for="profile_picture" class="form-label">Change Profile Picture</label>
                <input type="file" name="profile_picture" class="form-control">
            </div>
            <div class="form-group">
                <label for="first_name" class="form-label">First Name</label>
                <input type="text" name="first_name" class="form-control" value="<?php echo htmlspecialchars($user['first_name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="last_name" class="form-label">Last Name</label>
                <input type="text" name="last_name" class="form-control" value="<?php echo htmlspecialchars($user['last_name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            <div class="form-group text-center">
                <button type="submit" class="btn btn-primary mt-4">Save Changes</button>
            </div>
        </form>
    </div>

    <footer>
        <p>&copy; 2024 EM' Quality Shoes. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
