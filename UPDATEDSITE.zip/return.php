<?php
require_once 'includes/functions/functions.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $order_item_id = $_POST['order_item_id'];
    $quantity = $_POST['quantity'];
    $reason = $_POST['reason'];

    try {
        if (!isset($pdo)) {
            $pdo = new PDO("mysql:host=localhost;dbname=shoeshop", "root", "");
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }

        // Check if the user owns this order item
        $stmt = $pdo->prepare("SELECT * FROM order_items oi 
                               JOIN orders o ON oi.order_id = o.id 
                               WHERE oi.id = :order_item_id AND o.user_id = :user_id");
        $stmt->execute(['order_item_id' => $order_item_id, 'user_id' => $user_id]);
        $item = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($item && $quantity <= $item['quantity']) {
            // Insert the return request
            $insert = $pdo->prepare("INSERT INTO returns (user_id, order_item_id, quantity, reason) 
                                     VALUES (:user_id, :order_item_id, :quantity, :reason)");
            $insert->execute([
                'user_id' => $user_id,
                'order_item_id' => $order_item_id,
                'quantity' => $quantity,
                'reason' => $reason
            ]);
            $message = "Return request submitted successfully!";
        } else {
            $message = "Invalid item selection or quantity!";
        }
    } catch (PDOException $e) {
        $message = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return Item - EmShoe</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'templates/header.php'; ?>
<div class="container mt-5">
    <h2>Return Item</h2>
    <?php if ($message): ?>
        <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <form method="POST" action="return.php">
        <div class="form-group">
            <label for="order_item_id">Select Item to Return:</label>
            <select class="form-control" name="order_item_id" required>
                <option value="">-- Select Item --</option>
                <?php
                // Fetch user's order items for selection
                $stmt = $pdo->prepare("
                    SELECT oi.id, p.name, oi.quantity 
                    FROM order_items oi
                    JOIN orders o ON oi.order_id = o.id
                    JOIN products p ON oi.product_id = p.product_id
                    WHERE o.user_id = :user_id
                ");
                $stmt->execute(['user_id' => $user_id]);
                $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($items as $item) {
                    echo "<option value='{$item['id']}'>{$item['name']} (Quantity: {$item['quantity']})</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="quantity">Quantity to Return:</label>
            <input type="number" class="form-control" name="quantity" min="1" required>
        </div>
        <div class="form-group">
            <label for="reason">Reason for Return:</label>
            <textarea class="form-control" name="reason" rows="4" required></textarea>
        </div>
        <button type="submit" class="btn btn-danger">Submit Return Request</button>
    </form>
</div>
</body>
</html>
