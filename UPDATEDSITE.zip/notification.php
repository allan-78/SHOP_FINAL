<?php
require_once 'includes/functions/functions.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

try {
    if (!isset($pdo)) {
        $pdo = new PDO("mysql:host=localhost;dbname=shoeshop", "root", "");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    // Modified query to calculate grand_total from order_items
    $sql = "
        SELECT 
            n.message, 
            n.created_at,
            GROUP_CONCAT(CONCAT(p.name, ' (x', oi.quantity, ')') SEPARATOR ', ') AS products,
            SUM(oi.price * oi.quantity) AS subtotal
        FROM 
            notifications n
        LEFT JOIN 
            orders o ON n.order_id = o.id
        LEFT JOIN 
            order_items oi ON o.id = oi.order_id
        LEFT JOIN 
            products p ON oi.product_id = p.product_id
        WHERE 
            n.user_id = :user_id
        GROUP BY 
            n.id
        ORDER BY 
            n.created_at DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['user_id' => $user_id]);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - EmShoe</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }
        .container {
            margin-top: 50px;
        }
        .notification {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 15px;
        }
        .notification-time {
            font-size: 0.8em;
            color: #6c757d;
        }
    </style>
</head>
<body>
<?php include 'templates/header.php'; ?>
<div class="container">
    <h2 class="mb-4">Notifications</h2>
    <?php if (!empty($notifications)): ?>
        <?php foreach ($notifications as $notification): ?>
            <div class="notification">
                <p><?php echo htmlspecialchars($notification['message']); ?></p>
                <?php if (!empty($notification['products'])): ?>
                    <p><strong>Products/Services: </strong><?php echo htmlspecialchars($notification['products']); ?></p>
                <?php endif; ?>
                <?php if (!empty($notification['subtotal'])): ?>
                    <p><strong>Subtotal: </strong>$<?php echo number_format($notification['subtotal'], 2); ?></p>
                <?php endif; ?>
                <p class="notification-time"><?php echo htmlspecialchars($notification['created_at']); ?></p>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p class="text-center">No notifications found.</p>
    <?php endif; ?>
</div>
</body>
</html>
