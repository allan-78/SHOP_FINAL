<?php
require_once 'includes/functions/functions.php'; // Ensure the correct path
session_start();

// Connect to the database
$pdo = new PDO("mysql:host=localhost;dbname=shoeshop", "root", "");  // Adjust DB credentials if necessary

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch the product ID from the URL
if (isset($_GET['product_id']) && is_numeric($_GET['product_id'])) {
    $product_id = (int)$_GET['product_id'];
    
    // Fetch product details (optional, to display product name)
    $product = getProduct($product_id); // Assuming getProduct() fetches the product details from the DB
    
    // Fetch existing review if any
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT * FROM reviews WHERE product_id = :product_id AND user_id = :user_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['product_id' => $product_id, 'user_id' => $user_id]);
    $existing_review = $stmt->fetch(PDO::FETCH_ASSOC);

} else {
    echo "Invalid product ID.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rating = $_POST['rating'];
    $review_text = $_POST['review_text'];
    
    // Insert or update the review
    if ($existing_review) {
        // Update existing review
        $sql = "UPDATE reviews SET rating = :rating, review_text = :review_text, updated_at = CURRENT_TIMESTAMP WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'rating' => $rating, 
            'review_text' => $review_text, 
            'id' => $existing_review['id']  // Ensure the 'id' is correctly accessed here
        ]);
    } else {
        // Insert new review
        $sql = "INSERT INTO reviews (product_id, user_id, rating, review_text) VALUES (:product_id, :user_id, :rating, :review_text)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'product_id' => $product_id,
            'user_id' => $user_id,
            'rating' => $rating,
            'review_text' => $review_text
        ]);
    }

    // Success message and redirect to view_reviews.php for the specific product
    $_SESSION['message'] = "Your review has been submitted successfully!";
    header("Location: view_reviews.php?product_id=$product_id");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
/* Product Review Section */
.review-section {
    background-color: #fff;
    padding: 50px 20px;
    border-radius: 10px;
    margin-top: 30px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.review-section h2 {
    font-size: 2.5em;
    color: #333;
    text-align: center;
    margin-bottom: 40px;
    text-transform: uppercase;
}

.review-grid {
    display: flex;
    flex-direction: column;
    gap: 20px;
    align-items: center;
}

.review-item {
    background-color: #f9f9f9;
    padding: 20px;
    border-radius: 10px;
    width: 80%;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: row;
    gap: 20px;
    align-items: flex-start;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.review-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
}

.review-item img {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #007bff;
}

.review-text {
    flex: 1;
}

.review-text h4 {
    font-size: 1.5em;
    margin-bottom: 10px;
    color: #333;
    font-weight: bold;
}

.review-text p {
    font-size: 1.1em;
    color: #555;
    margin: 10px 0;
}

.review-rating {
    display: flex;
    gap: 5px;
    align-items: center;
}

.review-rating span {
    font-size: 1.5em;
    color: #ffc107;
}

.review-form {
    margin-top: 30px;
    background-color: #f4f4f9;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.review-form input, .review-form textarea {
    width: 100%;
    padding: 15px;
    margin-bottom: 20px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 1.2em;
    color: #333;
}

.review-form button {
    background-color: #007bff;
    color: #fff;
    font-size: 1.2em;
    padding: 15px 30px;
    border: none;
    border-radius: 30px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.review-form button:hover {
    background-color: #0056b3;
    transform: scale(1.05);
}

/* Mobile Responsiveness */
@media (max-width: 768px) {
    .review-item {
        flex-direction: column;
        align-items: center;
    }

    .review-item img {
        width: 100px;
        height: 100px;
    }

    .review-text h4 {
        font-size: 1.3em;
    }
}

    </style>
</head>
<body>

<header>
<?php include 'templates/header.php'; ?>
</header>

<div class="container">
    <div class="card">
        <div class="card-body">
            <h2 class="card-title">Leave a Review for "<?php echo htmlspecialchars($product['name']); ?>"</h2>

            <?php if ($existing_review): ?>
                <div class="alert alert-info">
                    <p><strong>Your previous review:</strong></p>
                    <p>Rating: <?php echo $existing_review['rating']; ?>/5</p>
                    <p>Review: <?php echo $existing_review['review_text']; ?></p>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label for="rating" class="form-label">Rating (1-5):</label>
                    <input type="number" class="form-control" name="rating" min="1" max="5" value="<?php echo $existing_review ? $existing_review['rating'] : ''; ?>" required>
                </div>

                <div class="mb-3">
                    <label for="review_text" class="form-label">Review:</label>
                    <textarea class="form-control" name="review_text" rows="4" required><?php echo $existing_review ? $existing_review['review_text'] : ''; ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Submit Review</button>
            </form>
        </div>
    </div>
</div>

<footer>
    <p>&copy; 2024 EM' Quality Shoes. All rights reserved. <a href="terms.php">Terms of Service</a> | <a href="privacy.php">Privacy Policy</a></p>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
